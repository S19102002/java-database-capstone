import { openModal } from "../components/modals.js";
import { getDoctors, filterDoctors, saveDoctor } from "../services/doctorServices.js";
import { createDoctorCard } from "../components/doctorCard.js";

// Load all doctors on page load
window.onload = () => {
    const addDocBtn = document.getElementById('addDocBtn');
    if (addDocBtn) {
        addDocBtn.addEventListener('click', () => {
            openModal('addDoctor');
        });
    }

    loadDoctorCards();

    document.getElementById("searchBar").addEventListener("input", filterDoctorsOnChange);
    document.getElementById("filterTime").addEventListener("change", filterDoctorsOnChange);
    document.getElementById("filterSpecialty").addEventListener("change", filterDoctorsOnChange);
};

async function loadDoctorCards() {
    const contentDiv = document.getElementById("content");
    contentDiv.innerHTML = "";
    const doctors = await getDoctors();
    renderDoctorCards(doctors);
}

function renderDoctorCards(doctors) {
    const contentDiv = document.getElementById("content");
    contentDiv.innerHTML = "";
    if (doctors.length === 0) {
        contentDiv.innerHTML = "<p>No doctors found.</p>";
        return;
    }
    doctors.forEach(doctor => {
        const card = createDoctorCard(doctor);
        contentDiv.appendChild(card);
    });
}

async function filterDoctorsOnChange() {
    const name = document.getElementById("searchBar").value;
    const time = document.getElementById("filterTime").value;
    const specialty = document.getElementById("filterSpecialty").value;
    const doctors = await filterDoctors(name, time, specialty);
    renderDoctorCards(doctors);
}

export async function adminAddDoctor() {
    const token = localStorage.getItem("token");
    if (!token) {
        alert("Unauthorized access. Please login again.");
        return;
    }

    const name = document.getElementById("docName").value;
    const email = document.getElementById("docEmail").value;
    const password = document.getElementById("docPassword").value;
    const mobile = document.getElementById("docMobile").value;
    const specialty = document.getElementById("docSpecialty").value;

    const availability = Array.from(document.querySelectorAll(".availability-checkbox:checked"))
        .map(cb => cb.value);

    const doctor = {
        name,
        email,
        password,
        mobile,
        specialty,
        availability
    };

    const response = await saveDoctor(doctor, token);
    if (response.success) {
        alert("Doctor added successfully!");
        document.getElementById("modal").style.display = "none";
        loadDoctorCards();
    } else {
        alert("Failed to add doctor: " + response.message);
    }
}
