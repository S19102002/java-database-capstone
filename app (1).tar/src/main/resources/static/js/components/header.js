function renderHeader() {
  const headerDiv = document.getElementById("header");
  if (!headerDiv) return;

  if (window.location.pathname.endsWith("/")) {
    localStorage.removeItem("userRole");
    localStorage.removeItem("token");
  }

  const role = localStorage.getItem("userRole");
  const token = localStorage.getItem("token");

  if ((role === "loggedPatient" || role === "admin" || role === "doctor") && !token) {
    localStorage.removeItem("userRole");
    alert("Session expired or invalid login. Please log in again.");
    window.location.href = "/";
    return;
  }

  let headerContent = '<nav class="header-nav">';

  if (role === "admin") {
    headerContent += \`
      <button id="addDocBtn" class="adminBtn" onclick="openModal('addDoctor')">Add Doctor</button>
      <a href="#" id="logoutBtn">Logout</a>
    \`;
  } else if (role === "doctor") {
    headerContent += \`
      <a href="/templates/doctor/doctorDashboard.html">Home</a>
      <a href="#" id="logoutBtn">Logout</a>
    \`;
  } else if (role === "patient") {
    headerContent += \`
      <a href="/login.html">Login</a>
      <a href="/signup.html">Sign Up</a>
    \`;
  } else if (role === "loggedPatient") {
    headerContent += \`
      <a href="/static/pages/patientDashboard.html">Home</a>
      <a href="/appointments.html">Appointments</a>
      <a href="#" id="logoutPatientBtn">Logout</a>
    \`;
  }

  headerContent += "</nav>";
  headerDiv.innerHTML = headerContent;

  attachHeaderButtonListeners();
}

function attachHeaderButtonListeners() {
  const logoutBtn = document.getElementById("logoutBtn");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", logout);
  }

  const logoutPatientBtn = document.getElementById("logoutPatientBtn");
  if (logoutPatientBtn) {
    logoutPatientBtn.addEventListener("click", logoutPatient);
  }
}

function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("userRole");
  window.location.href = "/";
}

function logoutPatient() {
  localStorage.removeItem("token");
  localStorage.setItem("userRole", "patient");
  window.location.href = "/static/pages/patientDashboard.html";
}

document.addEventListener("DOMContentLoaded", renderHeader);
