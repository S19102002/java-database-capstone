import { getAllAppointments } from './services/appointmentRecordService.js';
import { createPatientRow } from './components/patientRows.js';

let appointmentTableBody;
let selectedDate = new Date().toISOString().split('T')[0];
let token = localStorage.getItem("token");
let patientName = null;

document.addEventListener("DOMContentLoaded", () => {
    appointmentTableBody = document.getElementById("patientTableBody");
    document.getElementById("datePicker").value = selectedDate;

    document.getElementById("searchBar").addEventListener("input", (e) => {
        patientName = e.target.value.trim() || "null";
        loadAppointments();
    });

    document.getElementById("todayButton").addEventListener("click", () => {
        selectedDate = new Date().toISOString().split('T')[0];
        document.getElementById("datePicker").value = selectedDate;
        loadAppointments();
    });

    document.getElementById("datePicker").addEventListener("change", (e) => {
        selectedDate = e.target.value;
        loadAppointments();
    });

    renderContent?.();
    loadAppointments();
});

async function loadAppointments() {
    try {
        const appointments = await getAllAppointments(selectedDate, patientName || "null", token);
        appointmentTableBody.innerHTML = "";

        if (!appointments || appointments.length === 0) {
            const row = document.createElement("tr");
            row.innerHTML = `<td colspan="5" class="noPatientRecord">No Appointments found for today</td>`;
            appointmentTableBody.appendChild(row);
        } else {
            appointments.forEach((appointment) => {
                const row = createPatientRow(appointment.patient, appointment);
                appointmentTableBody.appendChild(row);
            });
        }
    } catch (error) {
        console.error("Error loading appointments:", error);
        const row = document.createElement("tr");
        row.innerHTML = `<td colspan="5" class="noPatientRecord">Error loading appointments</td>`;
        appointmentTableBody.appendChild(row);
    }
}
