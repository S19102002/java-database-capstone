import { API_BASE_URL } from "../config/config.js";

const PATIENT_API = API_BASE_URL + '/patient';

// 1. Patient Signup
export async function patientSignup(data) {
    try {
        const response = await fetch(PATIENT_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        const result = await response.json();
        return { success: response.ok, message: result.message || "Signup processed." };
    } catch (error) {
        console.error("Signup error:", error);
        return { success: false, message: "Internal error occurred during signup." };
    }
}

// 2. Patient Login
export async function patientLogin(data) {
    try {
        const response = await fetch(PATIENT_API + '/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        return response;
    } catch (error) {
        console.error("Login error:", error);
        return null;
    }
}

// 3. Get Logged-in Patient Data
export async function getPatientData(token) {
    try {
        const response = await fetch(PATIENT_API + `/${token}`);
        if (!response.ok) throw new Error("Failed to fetch patient data");
        return await response.json();
    } catch (error) {
        console.error("Fetch patient data error:", error);
        return null;
    }
}

// 4. Get Patient Appointments
export async function getPatientAppointments(id, token, user) {
    try {
        const url = `${PATIENT_API}/${id}/${token}?user=${user}`;
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to fetch appointments");
        return await response.json();
    } catch (error) {
        console.error("Get appointments error:", error);
        return null;
    }
}

// 5. Filter Appointments
export async function filterAppointments(condition, name, token) {
    try {
        const url = `${PATIENT_API}/filter/${condition}/${name}/${token}`;
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to filter appointments");
        return await response.json();
    } catch (error) {
        console.error("Filter appointments error:", error);
        return [];
    }
}
