package com.clinicmanagement.controller;

import com.clinicmanagement.model.Admin;
import com.clinicmanagement.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("${api.path}" + "admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @PostMapping
    public ResponseEntity<Map<String, String>> adminLogin(@RequestBody Admin admin) {
        // Call the service to validate the admin and generate token if valid
        return adminService.validateAdmin(admin);
    }
}
