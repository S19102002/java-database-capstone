package com.clinic.service;

import com.clinic.model.*;
import com.clinic.repository.*;
import com.clinic.security.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class Service {

    @Autowired
    private TokenService tokenService;

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private DoctorService doctorService;

    @Autowired
    private PatientService patientService;

    public ResponseEntity<Map<String, String>> validateToken(String token, String user) {
        if (!tokenService.validateToken(token, user)) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "Token is invalid or expired");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(error);
        }
        return ResponseEntity.ok().body(Collections.singletonMap("message", "Valid token"));
    }

    public ResponseEntity<Map<String, String>> validateAdmin(Admin receivedAdmin) {
        Admin admin = adminRepository.findByUsername(receivedAdmin.getUsername());
        if (admin != null && admin.getPassword().equals(receivedAdmin.getPassword())) {
            String token = tokenService.generateToken(receivedAdmin.getUsername());
            return ResponseEntity.ok().body(Collections.singletonMap("token", token));
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Collections.singletonMap("error", "Invalid username or password"));
    }

    public Map<String, Object> filterDoctor(String name, String specialty, String time) {
        if (name != null && specialty != null && time != null)
            return doctorService.filterDoctorsByNameSpecilityandTime(name, specialty, time);
        if (name != null && specialty != null)
            return doctorService.filterDoctorByNameAndSpecility(name, specialty);
        if (name != null && time != null)
            return doctorService.filterDoctorByNameAndTime(name, time);
        if (specialty != null && time != null)
            return doctorService.filterDoctorByTimeAndSpecility(specialty, time);
        if (name != null)
            return Collections.singletonMap("data", doctorService.findDoctorByName(name).get("data"));
        if (specialty != null)
            return doctorService.filterDoctorBySpecility(specialty);
        if (time != null)
            return doctorService.filterDoctorsByTime(time);
        return Collections.singletonMap("data", doctorService.getDoctors());
    }

    public int validateAppointment(Appointment appointment) {
        Optional<Doctor> doctorOptional = doctorRepository.findById(appointment.getDoctor().getId());
        if (!doctorOptional.isPresent()) return -1;

        List<String> availableSlots = doctorService.getDoctorAvailability(
                appointment.getDoctor().getId(), appointment.getAppointmentTime().toLocalDate()
        );

        String slot = appointment.getAppointmentTime().toLocalTime().toString();
        return availableSlots.contains(slot) ? 1 : 0;
    }

    public boolean validatePatient(Patient patient) {
        Patient existing = patientRepository.findByEmailOrPhone(patient.getEmail(), patient.getPhone());
        return existing == null;
    }

    public ResponseEntity<Map<String, String>> validatePatientLogin(Login login) {
        Patient patient = patientRepository.findByEmail(login.getEmail());
        if (patient != null && patient.getPassword().equals(login.getPassword())) {
            String token = tokenService.generateToken(patient.getEmail());
            return ResponseEntity.ok().body(Collections.singletonMap("token", token));
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Collections.singletonMap("error", "Invalid email or password"));
    }

    public ResponseEntity<Map<String, Object>> filterPatient(String condition, String name, String token) {
        String email = tokenService.extractEmail(token);
        Patient patient = patientRepository.findByEmail(email);

        if (patient == null)
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Collections.singletonMap("error", "Unauthorized access"));

        if (condition != null && name != null)
            return patientService.filterByDoctorAndCondition(condition, name, patient.getId());
        if (condition != null)
            return patientService.filterByCondition(condition, patient.getId());
        if (name != null)
            return patientService.filterByDoctor(name, patient.getId());

        return patientService.getPatientAppointment(patient.getId(), token);
    }
}
