package com.clinic.controller;

import com.clinic.dto.Login;
import com.clinic.model.Patient;
import com.clinic.service.PatientService;
import com.clinic.service.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/patient")
public class PatientController {

    @Autowired
    private PatientService patientService;

    @Autowired
    private Service service;

    // 1. Get Patient Details
    @GetMapping("/{token}")
    public ResponseEntity<Map<String, Object>> getPatientDetails(@PathVariable String token) {
        if (!service.validateToken(token, "patient").getStatusCode().is2xxSuccessful()) {
            return service.validateToken(token, "patient");
        }
        return patientService.getPatientDetails(token);
    }

    // 2. Create a New Patient
    @PostMapping()
    public ResponseEntity<Map<String, String>> createPatient(@RequestBody Patient patient) {
        boolean doesNotExist = service.validatePatient(patient);
        if (!doesNotExist) {
            return ResponseEntity.status(409).body(Map.of("message", "Patient with email id or phone no already exist"));
        }

        int created = patientService.createPatient(patient);
        if (created == 1) {
            return ResponseEntity.status(201).body(Map.of("message", "Signup successful"));
        } else {
            return ResponseEntity.status(500).body(Map.of("message", "Internal server error"));
        }
    }

    // 3. Patient Login
    @PostMapping("/login")
    public ResponseEntity<Map<String, String>> login(@RequestBody Login login) {
        return service.validatePatientLogin(login);
    }

    // 4. Get Patient Appointments
    @GetMapping("/{id}/{token}")
    public ResponseEntity<Map<String, Object>> getAppointments(@PathVariable Long id, @PathVariable String token) {
        if (!service.validateToken(token, "patient").getStatusCode().is2xxSuccessful()) {
            return service.validateToken(token, "patient");
        }
        return patientService.getPatientAppointment(id, token);
    }

    // 5. Filter Patient Appointments
    @GetMapping("/filter/{condition}/{name}/{token}")
    public ResponseEntity<Map<String, Object>> filterAppointments(
            @PathVariable String condition,
            @PathVariable String name,
            @PathVariable String token
    ) {
        if (!service.validateToken(token, "patient").getStatusCode().is2xxSuccessful()) {
            return service.validateToken(token, "patient");
        }
        return service.filterPatient(condition, name, token);
    }
}
