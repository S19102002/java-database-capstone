package com.example.dto;

public class Login {

    private String email;
    private String password;

    // Default constructor (required for deserialization)
    public Login() {
    }

    // Parameterized constructor (optional)
    public Login(String email, String password) {
        this.email = email;
        this.password = password;
    }

    // Getter and Setter for email
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Getter and Setter for password
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
