package com.example.service;

import com.example.dto.AppointmentDTO;
import com.example.model.Appointment;
import com.example.model.Patient;
import com.example.repository.AppointmentRepository;
import com.example.repository.PatientRepository;
import com.example.security.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private TokenService tokenService;

    // 1. Save a new patient
    public int createPatient(Patient patient) {
        try {
            patientRepository.save(patient);
            return 1;
        } catch (Exception e) {
            return 0;
        }
    }

    // 2. Get all appointments for a patient
    public ResponseEntity<Map<String, Object>> getPatientAppointment(Long id, String token) {
        String email = tokenService.extractEmail(token);
        Patient patient = patientRepository.findByEmail(email);

        if (patient == null || !patient.getId().equals(id)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("message", "Unauthorized access"));
        }

        List<Appointment> appointments = appointmentRepository.findByPatientId(id);
        List<AppointmentDTO> dtos = appointments.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());

        return ResponseEntity.ok(Map.of("appointments", dtos));
    }

    // 3. Filter by past/future condition
    public ResponseEntity<Map<String, Object>> filterByCondition(String condition, Long id) {
        List<Appointment> all = appointmentRepository.findByPatientId(id);
        LocalDateTime now = LocalDateTime.now();

        List<AppointmentDTO> filtered = all.stream()
                .filter(app -> {
                    if ("past".equalsIgnoreCase(condition)) {
                        return app.getAppointmentTime().isBefore(now);
                    } else if ("future".equalsIgnoreCase(condition)) {
                        return app.getAppointmentTime().isAfter(now);
                    }
                    return false;
                })
                .map(this::convertToDTO)
                .collect(Collectors.toList());

        return ResponseEntity.ok(Map.of("appointments", filtered));
    }

    // 4. Filter by doctor name
    public ResponseEntity<Map<String, Object>> filterByDoctor(String name, Long patientId) {
        List<Appointment> results = appointmentRepository.filterByDoctorNameAndPatientId(name, patientId);
        List<AppointmentDTO> dtos = results.stream().map(this::convertToDTO).collect(Collectors.toList());
        return ResponseEntity.ok(Map.of("appointments", dtos));
    }

    // 5. Filter by doctor and condition
    public ResponseEntity<Map<String, Object>> filterByDoctorAndCondition(String condition, String name, long patientId) {
        List<Appointment> results = appointmentRepository.filterByDoctorNameAndPatientIdAndStatus(
                name, patientId, "past".equalsIgnoreCase(condition) ? 1 : 0);

        List<AppointmentDTO> dtos = results.stream().map(this::convertToDTO).collect(Collectors.toList());
        return ResponseEntity.ok(Map.of("appointments", dtos));
    }

    // 6. Get patient details from token
    public ResponseEntity<Map<String, Object>> getPatientDetails(String token) {
        String email = tokenService.extractEmail(token);
        Patient patient = patientRepository.findByEmail(email);

        if (patient == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("message", "Patient not found"));
        }

        return ResponseEntity.ok(Map.of("patient", patient));
    }

    // Helper method to convert to DTO
    private AppointmentDTO convertToDTO(Appointment a) {
        return new AppointmentDTO(
                a.getId(),
                a.getDoctor().getId(),
                a.getDoctor().getName(),
                a.getPatient().getId(),
                a.getPatient().getName(),
                a.getPatient().getEmail(),
                a.getPatient().getPhone(),
                a.getPatient().getAddress(),
                a.getAppointmentTime(),
                a.getStatus()
        );
    }
} 
