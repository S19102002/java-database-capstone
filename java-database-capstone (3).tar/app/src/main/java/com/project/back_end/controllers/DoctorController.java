package com.had.backend.controller;

import com.had.backend.entity.Doctor;
import com.had.backend.entity.Login;
import com.had.backend.service.DoctorService;
import com.had.backend.service.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("${api.path}" + "doctor")
public class DoctorController {

    @Autowired
    private DoctorService doctorService;

    @Autowired
    private Service service;

    @GetMapping("/availability/{user}/{doctorId}/{date}/{token}")
    public ResponseEntity<Map<String, Object>> getDoctorAvailability(@PathVariable String user,
                                                                     @PathVariable Long doctorId,
                                                                     @PathVariable String date,
                                                                     @PathVariable String token) {
        ResponseEntity<Map<String, String>> response = service.validateToken(token, user);
        if (response.getStatusCode().isError()) return new ResponseEntity<>(Map.of("error", "Invalid token"), response.getStatusCode());

        List<String> availableSlots = doctorService.getDoctorAvailability(doctorId, LocalDate.parse(date));
        Map<String, Object> result = new HashMap<>();
        result.put("slots", availableSlots);
        return ResponseEntity.ok(result);
    }

    @GetMapping
    public ResponseEntity<Map<String, Object>> getAllDoctors() {
        List<Doctor> doctors = doctorService.getDoctors();
        Map<String, Object> result = new HashMap<>();
        result.put("doctors", doctors);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/{token}")
    public ResponseEntity<Map<String, String>> addDoctor(@RequestBody Doctor doctor, @PathVariable String token) {
        ResponseEntity<Map<String, String>> response = service.validateToken(token, "admin");
        if (response.getStatusCode().isError()) return response;

        int status = doctorService.saveDoctor(doctor);
        Map<String, String> result = new HashMap<>();
        if (status == 1) result.put("message", "Doctor added to db");
        else if (status == -1) result.put("message", "Doctor already exists");
        else result.put("message", "Some internal error occurred");

        return ResponseEntity.status(status == 1 ? 201 : status == -1 ? 409 : 500).body(result);
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, String>> loginDoctor(@RequestBody Login login) {
        return doctorService.validateDoctor(login);
    }

    @PutMapping("/{token}")
    public ResponseEntity<Map<String, String>> updateDoctor(@RequestBody Doctor doctor, @PathVariable String token) {
        ResponseEntity<Map<String, String>> response = service.validateToken(token, "doctor");
        if (response.getStatusCode().isError()) return response;

        int status = doctorService.updateDoctor(doctor);
        Map<String, String> result = new HashMap<>();
        if (status == 1) result.put("message", "Doctor updated");
        else if (status == -1) result.put("message", "Doctor not found");
        else result.put("message", "Some internal error occurred");

        return ResponseEntity.status(status == 1 ? 200 : status == -1 ? 404 : 500).body(result);
    }

    @DeleteMapping("/{id}/{token}")
    public ResponseEntity<Map<String, String>> deleteDoctor(@PathVariable Long id, @PathVariable String token) {
        ResponseEntity<Map<String, String>> response = service.validateToken(token, "admin");
        if (response.getStatusCode().isError()) return response;

        int status = doctorService.deleteDoctor(id);
        Map<String, String> result = new HashMap<>();
        if (status == 1) result.put("message", "Doctor deleted successfully");
        else if (status == -1) result.put("message", "Doctor not found with id");
        else result.put("message", "Some internal error occurred");

        return ResponseEntity.status(status == 1 ? 200 : status == -1 ? 404 : 500).body(result);
    }

    @GetMapping("/filter/{name}/{time}/{speciality}")
    public ResponseEntity<Map<String, Object>> filterDoctors(@PathVariable String name,
                                                             @PathVariable String time,
                                                             @PathVariable String speciality) {
        return ResponseEntity.ok(service.filterDoctor(name, speciality, time));
    }
}  
